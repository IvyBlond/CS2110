/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=17x21 Klee Klee1721.png 
 * Time-stamp: Thursday 04/08/2021, 15:11:53
 * 
 * Image Information
 * -----------------
 * Klee1721.png 17@21
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef KLEE_H
#define KLEE_H

extern const unsigned short Klee1721[357];
#define KLEE1721_SIZE 714
#define KLEE1721_LENGTH 357
#define KLEE1721_WIDTH 17
#define KLEE1721_HEIGHT 21

#endif

