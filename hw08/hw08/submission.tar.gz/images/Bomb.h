/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=16x17 Bomb Bomb1617.png 
 * Time-stamp: Thursday 04/08/2021, 15:12:45
 * 
 * Image Information
 * -----------------
 * Bomb1617.png 16@17
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BOMB_H
#define BOMB_H

extern const unsigned short Bomb1617[272];
#define BOMB1617_SIZE 544
#define BOMB1617_LENGTH 272
#define BOMB1617_WIDTH 16
#define BOMB1617_HEIGHT 17

#endif

