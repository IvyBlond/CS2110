/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=24x11 fish fish.png.png 
 * Time-stamp: Thursday 04/08/2021, 05:08:36
 * 
 * Image Information
 * -----------------
 * fish.png.png 24@11
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FISH_H
#define FISH_H

extern const unsigned short fishpng[264];
#define FISHPNG_SIZE 528
#define FISHPNG_LENGTH 264
#define FISHPNG_WIDTH 24
#define FISHPNG_HEIGHT 11

#endif

