/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 Jean Jean.jpg 
 * Time-stamp: Friday 04/09/2021, 20:59:36
 * 
 * Image Information
 * -----------------
 * Jean.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef JEAN_H
#define JEAN_H

extern const unsigned short Jean[38400];
#define JEAN_SIZE 76800
#define JEAN_LENGTH 38400
#define JEAN_WIDTH 240
#define JEAN_HEIGHT 160

#endif

