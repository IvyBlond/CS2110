/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 water water.jpg 
 * Time-stamp: Thursday 04/08/2021, 15:13:24
 * 
 * Image Information
 * -----------------
 * water.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WATER_H
#define WATER_H

extern const unsigned short water[38400];
#define WATER_SIZE 76800
#define WATER_LENGTH 38400
#define WATER_WIDTH 240
#define WATER_HEIGHT 160

#endif

