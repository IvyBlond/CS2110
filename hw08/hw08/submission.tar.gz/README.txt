Klee has escaped from the confinment room to catch fish for you!
As normal, she will use her hand-made bomb to BLAST the fish.
Try to help her without hurting herself!
-------------------------------------------------------------------------------------------
1. Press Enter to start the game
2. Press-hold  Directions to control Klee's position
3. Press A (Z on the keyboard) to release bombs
4. If the bomb meets a fish, it will blast instaneously!
5. If Klee is inside the range of the bomb, she will be caught by Jean!
--------------------------------------------------------------------------------------------
Notes:
    the game ends when you have enough fish for Paimon's dinner (yes she will eat all of the 4 fish you caught)
    you will only have one life, because Jean has very good ears!
    the fish might move faster every time the bomb blasts
    sadly, Klee, since she just escaped from confinement room, only has one bomb with her, but you can reset it in the same way!
---------------------------------------------------------------------------------------------
Qingyu Chen
